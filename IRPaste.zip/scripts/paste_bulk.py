"""Bulk paste: generate N view-matched composites with diverse targets.

Targets are shuffled and consumed without replacement until the pool
is exhausted (then re-shuffled), so the first 2368 side composites
and 592 top composites each use a unique target. Backgrounds are
picked uniformly at random from the matching view class.

Uses the current default blend: ``laplacian`` + ``tv_smooth=True``.

Usage::

    uv run python scripts/paste_bulk.py --n 512 --seed 7

Outputs:
    outputs/_bulk/{idx:04d}_{view}_{bg}_{target}.png   — composite only
    outputs/_bulk/_contact_{k:02d}.png                 — 8×8 mosaic index
    outputs/_bulk/_manifest.csv                        — row per composite
"""

from __future__ import annotations

import argparse
import csv
import sys
import time
from pathlib import Path

import cv2
import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from irpaste import build_mask, load_sample  # noqa: E402
from irpaste.paste import paste_target, load_background  # noqa: E402
from irpaste.viewcls import classify_background, classify_target  # noqa: E402


_ORANGE = (0, 160, 255)
_CYAN = (255, 255, 0)


def _index_bgs(root: Path):
    side, top = [], []
    for p in sorted(root.iterdir()):
        if p.suffix.lower() not in {".png", ".bmp", ".jpg", ".jpeg", ".tif"}:
            continue
        try:
            bg = load_background(p)
            v = classify_background(bg, return_info=True, filename=p.name)
        except Exception:
            continue
        (side if v.kind == "side" else top).append(p)
    return side, top


def _index_targets(root: Path):
    side, top = [], []
    for xml in root.rglob("*.xml"):
        try:
            k = classify_target(xml)
        except Exception:
            continue
        (side if k == "side" else top).append(xml.with_suffix(""))
    return side, top


class _Shuffler:
    """Draw items without replacement; reshuffle when pool is exhausted."""

    def __init__(self, items, rng: np.random.Generator):
        self.items = list(items)
        self.rng = rng
        self._order: list[int] = []
        self._reshuffle()

    def _reshuffle(self):
        self._order = list(range(len(self.items)))
        self.rng.shuffle(self._order)

    def next(self):
        if not self.items:
            return None
        if not self._order:
            self._reshuffle()
        return self.items[self._order.pop()]


def _annotate(comp: np.ndarray, pr, tag: str) -> np.ndarray:
    bgr = cv2.cvtColor(comp, cv2.COLOR_GRAY2BGR)
    # Use tight bbox of mask pixels (drop transparent borders).
    ys, xs = np.where(pr.mask_patch)
    if ys.size > 0:
        x = pr.paste_xy[0] + int(xs.min())
        y = pr.paste_xy[1] + int(ys.min())
        pw = int(xs.max()) - int(xs.min())
        ph = int(ys.max()) - int(ys.min())
    else:
        x, y = pr.paste_xy
        ph, pw = pr.mask_patch.shape
    cv2.rectangle(bgr, (x, y), (x + pw, y + ph), _ORANGE, 1)
    if pr.bg_view.kind == "side":
        if pr.bg_view.horizon_curve is not None:
            pts = pr.bg_view.horizon_curve.polyline(n=max(32, bgr.shape[1] // 8))
            cv2.polylines(bgr, [pts], False, _CYAN, 1, cv2.LINE_AA)
        elif pr.bg_view.horizon_row is not None:
            hr = int(pr.bg_view.horizon_row)
            cv2.line(bgr, (0, hr), (bgr.shape[1] - 1, hr), _CYAN, 1, cv2.LINE_AA)
    cv2.putText(
        bgr, tag, (6, 18), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 0), 3, cv2.LINE_AA
    )
    cv2.putText(
        bgr, tag, (6, 18), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 1, cv2.LINE_AA
    )
    return bgr


def _annotate_multi(
    comp_or_bgr: np.ndarray,
    results: list,
    tags: list[str],
    crop_x: int = 0,
    crop_y: int = 0,
    scale_x: float = 1.0,
    scale_y: float = 1.0,
) -> np.ndarray:
    """Annotate composite with view type, ship labels, bboxes + horizon line.

    When called with no crop/scale params (original mode), *comp_or_bgr* is
    a full-size grayscale image; it is converted to BGR and annotated in
    full-image coordinates.

    When *crop_x* / *crop_y* / *scale_x* / *scale_y* are supplied, the
    image has already been cropped/resized to output size (512×512) and the
    annotation coordinates are adjusted accordingly.
    """
    if comp_or_bgr.ndim == 2:
        bgr = cv2.cvtColor(comp_or_bgr, cv2.COLOR_GRAY2BGR)
    else:
        bgr = comp_or_bgr.copy()
    for pr, tag in zip(results, tags):
        ys, xs = np.where(pr.mask_patch)
        if ys.size > 0:
            x = pr.paste_xy[0] + int(xs.min())
            y = pr.paste_xy[1] + int(ys.min())
            pw = int(xs.max()) - int(xs.min())
            ph = int(ys.max()) - int(ys.min())
        else:
            x, y = pr.paste_xy
            ph, pw = pr.mask_patch.shape
        # Adjust for crop/resize to output coordinates.
        x = int(round((x - crop_x) * scale_x))
        y = int(round((y - crop_y) * scale_y))
        pw = max(1, int(round(pw * scale_x)))
        ph = max(1, int(round(ph * scale_y)))
        cv2.rectangle(bgr, (x, y), (x + pw, y + ph), _ORANGE, 1)
        cv2.putText(
            bgr, tag, (x, max(12, y - 4)), cv2.FONT_HERSHEY_SIMPLEX,
            0.4, (0, 0, 0), 3, cv2.LINE_AA,
        )
        cv2.putText(
            bgr, tag, (x, max(12, y - 4)), cv2.FONT_HERSHEY_SIMPLEX,
            0.4, (0, 255, 0), 1, cv2.LINE_AA,
        )
    # Draw horizon once (use first result's bg_view).
    if results and results[0].bg_view.kind == "side":
        bv = results[0].bg_view
        if bv.horizon_curve is not None:
            pts = bv.horizon_curve.polyline(n=max(32, bgr.shape[1] // 8))
            adj = pts.astype(np.float64)
            adj[:, 0] = (adj[:, 0] - crop_x) * scale_x
            adj[:, 1] = (adj[:, 1] - crop_y) * scale_y
            cv2.polylines(bgr, [adj.round().astype(np.int32)], False, _CYAN, 1, cv2.LINE_AA)
        elif bv.horizon_row is not None:
            hr = int(round((bv.horizon_row - crop_y) * scale_y))
            cv2.line(bgr, (0, hr), (bgr.shape[1] - 1, hr), _CYAN, 1, cv2.LINE_AA)
    # Top-left: show view type + ship count
    view_label = f"{'Side' if results[0].bg_view.kind == 'side' else 'Top'} view  n={len(results)}" if results else f"n={len(results)}"
    cv2.putText(
        bgr, view_label, (6, 18), cv2.FONT_HERSHEY_SIMPLEX,
        0.5, (0, 0, 0), 3, cv2.LINE_AA,
    )
    cv2.putText(
        bgr, view_label, (6, 18), cv2.FONT_HERSHEY_SIMPLEX,
        0.5, (0, 255, 0), 1, cv2.LINE_AA,
    )
    return bgr


def _safe_stem(name: str, n: int = 16) -> str:
    s = "".join(c for c in name if c.isascii() and (c.isalnum() or c in "._-"))
    return (s or "x")[:n]


def _compute_label(
    pr, crop_x: int, crop_y: int, out_w: int, out_h: int
) -> tuple[float, float, float, float]:
    """Compute normalised YOLO HBB ``(cx, cy, w, h)`` in [0, 1] from a
    PasteResult, accounting for output cropping and clamping to bounds.

    Parameters
    ----------
    pr : PasteResult
        Result from paste_target.
    crop_x, crop_y : int
        Offset of the output crop within the full composite (0 if resized).
    out_w, out_h : int
        Output image dimensions (typically 512×512).
    """
    # Tight bbox of mask pixels in the full (uncropped) composite.
    ys, xs = np.where(pr.mask_patch)
    if ys.size == 0:
        mk_x0 = 0
        mk_y0 = 0
        pw = pr.mask_patch.shape[1]
        ph = pr.mask_patch.shape[0]
    else:
        mk_x0 = int(xs.min())
        mk_y0 = int(ys.min())
        pw = int(xs.max()) - mk_x0 + 1
        ph = int(ys.max()) - mk_y0 + 1
    px = pr.paste_xy[0] + mk_x0  # bbox left in full composite
    py = pr.paste_xy[1] + mk_y0  # bbox top in full composite

    # Map to output image space.
    ox0 = px - crop_x
    oy0 = py - crop_y
    ox1 = ox0 + pw
    oy1 = oy0 + ph

    # Clamp to output bounds.
    ox0_c = max(0, ox0)
    oy0_c = max(0, oy0)
    ox1_c = min(out_w, ox1)
    oy1_c = min(out_h, oy1)

    if ox1_c <= ox0_c or oy1_c <= oy0_c:
        return 0.5, 0.5, 0.0, 0.0

    pw_c = ox1_c - ox0_c
    ph_c = oy1_c - oy0_c
    cx_n = (ox0_c + ox1_c) / 2.0 / out_w
    cy_n = (oy0_c + oy1_c) / 2.0 / out_h
    w_n = pw_c / out_w
    h_n = ph_c / out_h
    return (
        float(np.clip(cx_n, 0.0, 1.0)),
        float(np.clip(cy_n, 0.0, 1.0)),
        float(np.clip(w_n, 0.0, 1.0)),
        float(np.clip(h_n, 0.0, 1.0)),
    )


def _write_multi_label(
    label_path: Path, labels: list[tuple[float, float, float, float]]
) -> None:
    """Write multi-line YOLO HBB label file (one line per ship)."""
    label_path.parent.mkdir(parents=True, exist_ok=True)
    with label_path.open("w", encoding="utf-8") as f:
        for cx, cy, w, h in labels:
            f.write(f"0 {cx:.6f} {cy:.6f} {w:.6f} {h:.6f}\n")


def _build_contact_sheet(
    paths: list[Path], cols: int = 8, tile: int = 160
) -> np.ndarray:
    tiles = []
    for p in paths:
        im = cv2.imread(str(p))
        if im is None:
            continue
        h, w = im.shape[:2]
        s = tile / max(h, w)
        im = cv2.resize(im, (int(w * s), int(h * s)))
        canvas = np.zeros((tile, tile, 3), dtype=np.uint8)
        oy, ox = (tile - im.shape[0]) // 2, (tile - im.shape[1]) // 2
        canvas[oy : oy + im.shape[0], ox : ox + im.shape[1]] = im
        tiles.append(canvas)
    if not tiles:
        return np.zeros((tile, tile, 3), dtype=np.uint8)
    rows = []
    for i in range(0, len(tiles), cols):
        chunk = tiles[i : i + cols]
        while len(chunk) < cols:
            chunk.append(np.zeros_like(tiles[0]))
        rows.append(np.concatenate(chunk, axis=1))
    return np.concatenate(rows, axis=0)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--targets-root", default="data/burkeIIA长波")
    ap.add_argument("--bg-root", default="data/background/test_1")
    ap.add_argument("--out", default="outputs/_bulk")
    ap.add_argument(
        "--n",
        type=int,
        default=None,
        help="composites to generate (omit to process every target exactly once)",
    )
    ap.add_argument("--seed", type=int, default=None, help="RNG seed (omit for random)")
    ap.add_argument(
        "--side-frac",
        type=float,
        default=0.80,
        help="fraction of composites that should be side-view",
    )
    ap.add_argument(
        "--contact-rows", type=int, default=8, help="rows per contact sheet"
    )
    ap.add_argument(
        "--contact-cols", type=int, default=8, help="cols per contact sheet"
    )
    ap.add_argument(
        "--augment-bg",
        action="store_true",
        help="randomly zoom-in and smart-crop background before pasting",
    )
    ap.add_argument(
        "--bg-scale-max",
        type=float,
        default=1.3,
        help="upper bound of background zoom-in factor (default 1.3)",
    )
    ap.add_argument(
        "--align-axis",
        action="store_true",
        help="rotate ship so its principal axis is parallel to the bg horizon (side-view only)",
    )
    ap.add_argument(
        "--ship-scale-min",
        type=float,
        default=0.55,
        help="lower bound of ship downscale factor (default 0.55)",
    )
    ap.add_argument(
        "--ship-scale-max",
        type=float,
        default=0.90,
        help="upper bound of ship downscale factor (default 0.90); set equal to "
        "--ship-scale-min for a fixed scale; set both to 1.0 to disable",
    )
    ap.add_argument(
        "--max-ships-per-bg",
        type=int,
        default=1,
        help="max ships per background (1-5); > 1 enables multi-ship compositing (default 1)",
    )
    args = ap.parse_args()

    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    out_clean = out / "clean"  # plain composites (dataset images)
    out_vis = out / "vis"  # annotated with bbox + horizon overlay
    out_labels = out / "labels"  # YOLO HBB label txts
    out_clean.mkdir(exist_ok=True)
    out_vis.mkdir(exist_ok=True)
    out_labels.mkdir(exist_ok=True)

    seed = (
        args.seed
        if args.seed is not None
        else int(np.random.default_rng().integers(0, 2**31))
    )
    print(f"seed: {seed}  (pass --seed {seed} to reproduce)")
    rng = np.random.default_rng(seed)

    t0 = time.time()
    print("indexing backgrounds ...")
    bg_side, bg_top = _index_bgs(Path(args.bg_root))
    print(f"  bg: {len(bg_side)} side, {len(bg_top)} top")
    print("indexing targets ...")
    tgt_side, tgt_top = _index_targets(Path(args.targets_root))
    print(f"  targets: {len(tgt_side)} side, {len(tgt_top)} top")
    print(f"  index took {time.time() - t0:.1f}s")

    # --- Build work queue -------------------------------------------------- #
    # When --n is omitted, collect every target stem exactly once (shuffled).
    # When --n is given, keep the original random-sampling mode with _Shuffler.
    if args.n is None:
        _all = [(s, "side") for s in tgt_side] + [(s, "top") for s in tgt_top]
        _arr = np.arange(len(_all))
        rng.shuffle(_arr)
        _work_queue: list | None = [_all[int(i)] for i in _arr]
        n_total = len(_work_queue)
        s_side = s_top = None
        print(f"  exhaustive mode: {n_total} targets queued")
    else:
        _work_queue = None
        n_total = args.n
        s_side = _Shuffler(tgt_side, np.random.default_rng(seed + 1))
        s_top = _Shuffler(tgt_top, np.random.default_rng(seed + 2))

    manifest_path = out / "_manifest.csv"
    with manifest_path.open("w", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(
            ["idx", "view", "bg", "target", "on_horizon", "paste_x", "paste_y", "out"]
        )

        produced = 0
        attempts = 0
        written: list[Path] = []
        per_tile = max(args.contact_rows * args.contact_cols, 16)
        _q_iter = iter(_work_queue) if _work_queue is not None else None

        t_gen = time.time()
        _TARGET = 512
        max_per_bg = max(1, min(args.max_ships_per_bg, 5))

        while produced < n_total:
            # --- Build a batch: collect 1 to max_per_bg random ships sharing one bg --- #
            n_ships_this_batch = int(rng.integers(1, max_per_bg + 1))
            batch_stems: list[tuple] = []  # [(tgt_stem, kind, bg_path), ...]
            batch_kind = None
            batch_bg_path = None

            for _ in range(n_ships_this_batch):
                if _q_iter is not None:
                    try:
                        tgt_stem, kind = next(_q_iter)
                    except StopIteration:
                        break
                    bg_pool = bg_side if kind == "side" else bg_top
                    if not bg_pool:
                        continue
                    bg_path = bg_pool[int(rng.integers(len(bg_pool)))]
                else:
                    attempts += 1
                    if attempts > n_total * 4:
                        break
                    is_side = rng.random() < args.side_frac
                    if is_side and (not bg_side or not tgt_side):
                        is_side = False
                    if (not is_side) and (not bg_top or not tgt_top):
                        is_side = True
                    kind = "side" if is_side else "top"
                    bg_pool = bg_side if is_side else bg_top
                    tgt_stem = (s_side if is_side else s_top).next()
                    bg_path = bg_pool[int(rng.integers(len(bg_pool)))]

                if batch_bg_path is None:
                    batch_bg_path = bg_path
                    batch_kind = kind
                batch_stems.append((tgt_stem, kind, bg_path))

                # Early stop when no more targets can be added.
                if _q_iter is None and attempts > n_total * 4:
                    break

            if not batch_stems:
                break

            first_stem, first_kind, _ = batch_stems[0]
            first_bg_path = batch_stems[0][2]

            # --- Process the batch: load bg once, paste ships sequentially --- #
            try:
                bg = load_background(first_bg_path)
            except Exception as e:
                print(f"  skip batch (bg) {first_bg_path.name}: {e}")
                continue

            results: list = []  # list of PasteResult
            all_labels: list[tuple[float, float, float, float]] = []
            occupied_mask = np.zeros(bg.shape, dtype=bool)

            for i, (tgt_stem, kind, bg_path) in enumerate(batch_stems):
                try:
                    sample = load_sample(tgt_stem)
                    res = build_mask(sample)
                    if res.n_mask < 40:
                        continue
                    pr = paste_target(
                        sample,
                        res.mask,
                        bg,
                        bg_path=bg_path,
                        rng=np.random.default_rng(seed + 1000 + produced + i),
                        augment_bg=args.augment_bg,
                        bg_scale_range=(1.0, args.bg_scale_max),
                        align_to_horizon=args.align_axis,
                        ship_scale_range=(args.ship_scale_min, args.ship_scale_max),
                        occupied_mask=occupied_mask if i > 0 else None,
                    )
                except Exception as e:
                    print(f"  skip {tgt_stem.name}: {e}")
                    continue

                # Accumulate composite: first ship uses pr.composite directly;
                # subsequent ships are overlaid onto the accumulated result.
                if i == 0:
                    composite_full = pr.composite.copy()
                else:
                    x, y = pr.paste_xy
                    ph, pw = pr.mask_patch.shape
                    a = pr.mask_patch.astype(np.float32) * 0.85
                    roi_new = pr.composite[y:y+ph, x:x+pw].astype(np.float32)
                    roi_old = composite_full[y:y+ph, x:x+pw].astype(np.float32)
                    blended = roi_new * a + roi_old * (1.0 - a)
                    composite_full[y:y+ph, x:x+pw] = np.clip(blended, 0, 255).astype(np.uint8)

                # Update occupied mask.
                x, y = pr.paste_xy
                ph, pw = pr.mask_patch.shape
                fm = np.zeros(bg.shape, dtype=bool)
                fm[y:y+ph, x:x+pw] = pr.mask_patch
                occupied_mask = occupied_mask | fm

                results.append(pr)
                # Compute label and accumulate (bounds will be clamped after crop).
                all_labels.append(pr)  # store pr for later label computation

            if not results:
                continue

            # --- Build output name from the first ship in the batch --- #
            batch_idx = produced
            out_name = (
                f"{batch_idx:06d}_{batch_kind}"
                f"_{_safe_stem(first_bg_path.stem)}"
                f"_{_safe_stem(Path(first_stem).name)}"
                f"_n{len(results)}.png"
            )

            # --- Crop/resize output to 512×512 first, then annotate --- #
            H_full, W_full = composite_full.shape
            clean_full = cv2.cvtColor(composite_full, cv2.COLOR_GRAY2BGR)
            tags = [
                f"ship{i+1}{' H' if pr.target_on_horizon else ''}"
                for i, pr in enumerate(results)
            ]
            if H_full >= _TARGET and W_full >= _TARGET:
                _y0 = (H_full - _TARGET) // 2
                _x0 = (W_full - _TARGET) // 2
                clean_out = clean_full[_y0 : _y0 + _TARGET, _x0 : _x0 + _TARGET]
                vis_out = _annotate_multi(clean_out, results, tags, crop_x=_x0, crop_y=_y0)
            else:
                _y0, _x0 = 0, 0
                scale_x = _TARGET / max(W_full, 1)
                scale_y = _TARGET / max(H_full, 1)
                clean_out = cv2.resize(
                    clean_full, (_TARGET, _TARGET), interpolation=cv2.INTER_LINEAR
                )
                vis_out = _annotate_multi(clean_out, results, tags, scale_x=scale_x, scale_y=scale_y)

            cv2.imwrite(str(out_clean / out_name), clean_out)
            out_vis_path = out_vis / out_name
            cv2.imwrite(str(out_vis_path), vis_out)
            written.append(out_vis_path)

            # --- Multi-line YOLO HBB labels (one line per ship) --- #
            out_w = clean_out.shape[1]
            out_h = clean_out.shape[0]
            label_lines: list[tuple[float, float, float, float]] = []
            for pr in results:
                cx_n, cy_n, w_n, h_n = _compute_label(pr, _x0, _y0, out_w, out_h)
                label_lines.append((cx_n, cy_n, w_n, h_n))

            lbl_path = out_labels / Path(out_name).with_suffix(".txt").name
            _write_multi_label(lbl_path, label_lines)

            # --- Manifest row --- #
            target_names = ";".join(Path(s).name for s, _, _ in batch_stems)
            w.writerow(
                [
                    batch_idx,
                    batch_kind,
                    first_bg_path.name,
                    target_names,
                    int(results[0].target_on_horizon),
                    results[0].paste_xy[0],
                    results[0].paste_xy[1],
                    f"clean/{out_name}",
                ]
            )

            produced += 1
            if produced % 64 == 0:
                dt = time.time() - t_gen
                rate = produced / max(dt, 1e-3)
                eta = (n_total - produced) / max(rate, 1e-3)
                print(f"  {produced}/{n_total}   {rate:.1f}/s   ETA {eta:.0f}s")

    # Contact sheets (groups of contact_rows × contact_cols).
    print("building contact sheets ...")
    for k, start in enumerate(range(0, len(written), per_tile)):
        sheet = _build_contact_sheet(
            written[start : start + per_tile],
            cols=args.contact_cols,
            tile=160,
        )
        cv2.imwrite(str(out / f"_contact_{k:02d}.png"), sheet)

    print(
        f"wrote {produced} composites → {out_clean} (clean)  {out_vis} (vis)   "
        f"(total {time.time() - t0:.1f}s,   "
        f"manifest: {manifest_path.name})"
    )
    return 0


if __name__ == "__main__":
    sys.exit(main())
